<?php
$day = "6";

switch ($day) {
    case "1":
        echo "It is Monday";
        break;
    case "2":
        echo "It is today";
        break;
    case "3":
        echo "It is Wednesday";
        break;
	case "4":
        echo "It is Thursday";
        break;
    case "5":
        echo "It is Friday";
        break;
    case "6":
        echo "It is Saturday";
        break;
	case "7":
        echo "It is Sunday";
        break;
    default:
        echo "Invalid number";
}
?>
<?php
$favcolor = "red";

switch ($favcolor) {
  case "red":
    echo "Your favorite color is red";
    break;
  case "blue":
    echo "Your favorite color is blue";
    break;
  case "green":
    echo "Your favorite color is green";
    break;
  default:
    echo "Your favorite color is neither red, blue, nor green";
}
?>


