<?php 
session_start();



$_SESSION['name']="Ali";
$_SESSION['email']="aliraza@gmail.com";
$_SESSION['fname']="Raza";


echo "<h1>Session started</h1>";

?>