<?php 
echo "<h1>Session Destory</h1>";
    session_start();
    session_destroy();
?>